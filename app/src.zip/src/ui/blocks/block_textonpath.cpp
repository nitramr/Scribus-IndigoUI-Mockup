#include "block_textonpath.h"
#include "ui_block_textonpath.h"

BlockTextOnPath::BlockTextOnPath(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BlockTextOnPath)
{
    ui->setupUi(this);

    setup();
}

BlockTextOnPath::~BlockTextOnPath()
{
    delete ui;
}

void BlockTextOnPath::setup()
{
    QStringList type = QStringList();
    type.append("Default");
    type.append("Stair Step");
    type.append("Skew");
    ui->comboType->addItems(type);
}
