#ifndef CONFIGURATIONMANAGER_H
#define CONFIGURATIONMANAGER_H

#include <QString>



class ConfigurationManager
{
public:
    ConfigurationManager();

    static QString files(QString fileName);


private:

};

#endif // CONFIGURATIONMANAGER_H
