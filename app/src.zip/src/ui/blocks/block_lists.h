#ifndef BLOCK_LISTS_H
#define BLOCK_LISTS_H

#include <QWidget>

namespace Ui {
class BlockLists;
}

class BlockLists : public QWidget
{
    Q_OBJECT

    enum ListType {
        None = 0,
        DropCap = 1,
        Bullet = 2,
        Numbered = 3
    };

public:
    explicit BlockLists(QWidget *parent = nullptr);
    ~BlockLists();

private:
    Ui::BlockLists *ui;

    void setup();
    void connectSlots();

    ListType m_listType {ListType::None};

private slots:
    void changeListType();

};

#endif // BLOCK_LISTS_H
