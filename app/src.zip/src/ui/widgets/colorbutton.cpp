#include "colorbutton.h"
#include "popupmenu.h"

#include <QPainter>
#include <QPainterPath>
#include <helper.h>

/* ********************************************************************************* *
 *
 * Constructor + Setup
 *
 * ********************************************************************************* */
ColorButton::ColorButton(QWidget *parent) : QToolButton(parent)
{
    setFixedSize(26,26);
}

/* ********************************************************************************* *
 *
 * Members
 *
 * ********************************************************************************* */


bool ColorButton::hasDot()
{
    return m_hasDot;
}

ScColor ColorButton::color()
{
    return m_color;
}

VGradient ColorButton::gradient()
{
    return m_gradient;
}

void ColorButton::setContextWidget(QWidget *widget)
{
    PopupMenu * menu = new PopupMenu(widget);
    //menu->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowStaysOnTopHint);

    this->setCheckable(true);
    this->setMenu(menu);

    connect(this, &ColorButton::toggled, this, [menu](bool t) {
        menu->setVisible(t);

    });
}

/* ********************************************************************************* *
 *
 * Slots
 *
 * ********************************************************************************* */
void ColorButton::setBackground(QBrush background)
{
    m_background = background;
    update();
}

void ColorButton::setForeground(QBrush foreground)
{
    m_foreground = foreground;
    update();
}

void ColorButton::setHasDot(bool enabled)
{
    m_hasDot = enabled;
    update();
}

void ColorButton::setColor(ScColor color)
{
    m_color = color;

    QBrush background(color.toQColor());
    setBackground(background);
}

void ColorButton::setGradient(VGradient gradient)
{
    m_gradient = gradient;

    switch(m_gradient.type()){
    default:
    case GradientType::Linear:{
        QLinearGradient grad = gradient.toQLinearGradient();
        grad.setStart(0,0);
        grad.setFinalStop(width(), 0);

        QBrush background(grad);
        setBackground(background);
    }
        break;
    case GradientType::Radial:{
        QPointF center = QPointF( (width() -1 ) / 2., (height() -1 ) / 2. );
        QRadialGradient grad = gradient.toQRadialGradient();
        grad.setCenter( center );
        grad.setRadius( width()/2. );
        grad.setFocalPoint( center );

        QBrush background(grad);
        setBackground(background);
    }
        break;
    case GradientType::Conical:{
        QConicalGradient grad = gradient.toQConicalGradient();
        grad.setCenter(this->rect().center());

        QBrush background(grad);
        setBackground(background);
    }
        break;
    }






}

/* ********************************************************************************* *
 *
 * Events
 *
 * ********************************************************************************* */


void ColorButton::paintEvent(QPaintEvent *e)
{    
    Q_UNUSED(e);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    qreal smallSide = qMin(height(), width());
    QPainterPath mask;

    int m_inset = 1;

    // Draw Background Dot
    QRectF bDot(rect().center().x() - smallSide/2. + m_inset , rect().center().y() - smallSide/2. + m_inset, smallSide - m_inset, smallSide - m_inset);
    mask.addEllipse(bDot.adjusted(m_inset,m_inset,-m_inset,-m_inset));
    painter.setClipPath(mask);
    Helper::renderPattern(&painter, mask.boundingRect());
    painter.setClipping(false);

    Helper::renderColorHandle(&painter, bDot.center(), smallSide / 2. - m_inset, m_background);

    // Draw Foreground Dot
    if(m_hasDot){
        mask.clear();
        QRectF fDot(rect().center().x(), rect().center().y(), smallSide/2., smallSide/2.);
        mask.addEllipse(fDot.adjusted(m_inset,m_inset,-m_inset,-m_inset));
        painter.setClipPath(mask);
        Helper::renderPattern(&painter, mask.boundingRect());
        painter.setClipping(false);

        Helper::renderColorHandle(&painter, fDot.center() + QPointF(-0.5,-0.5), smallSide / 3.5 - m_inset, m_foreground);
    }

    painter.end();

}
