#ifndef COMBOBOX_BLENDMODE_H
#define COMBOBOX_BLENDMODE_H

#include <QComboBox>
#include <QWidget>

class ComboBoxBlendMode : public QComboBox
{
    Q_OBJECT
public:
    ComboBoxBlendMode(QWidget *parent = nullptr);
};

#endif // COMBOBOX_BLENDMODE_H
