#include "combobox_firstpage.h"

ComboBoxFirstPage::ComboBoxFirstPage(QWidget *parent) : QComboBox(parent)
{

}

void ComboBoxFirstPage::setPageLayout(PageLayout pageLayout)
{
    m_pageLayout = pageLayout;

    this->clear();

    switch(m_pageLayout){
    case PageLayout::Single:
        break;
    case PageLayout::Double:
        this->addItem("Left", FirstPage::Left);
        this->addItem("Right", FirstPage::Right);
        this->setCurrentIndex(1);
        break;
    case PageLayout::ThreeFacing:
        this->addItem("Left", FirstPage::Left);
        this->addItem("Middle", FirstPage::Middle);
        this->addItem("Right", FirstPage::Right);
        break;
    case PageLayout::FourFacing:
        this->addItem("Left", FirstPage::Left);
        this->addItem("Middle Left", FirstPage::MiddleLeft);
        this->addItem("Middle Right", FirstPage::MiddleRight);
        this->addItem("Right", FirstPage::Right);
        break;
    }
}

PageLayout ComboBoxFirstPage::pageLayout()
{
    return m_pageLayout;
}
