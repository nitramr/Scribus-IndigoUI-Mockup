#include "block_alignment.h"
#include "iconmanager.h"
#include "ui_block_alignment.h"

/* ********************************************************************************* *
 *
 * Constructor + Setup
 *
 * ********************************************************************************* */

BlockAlignment::BlockAlignment(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BlockAlignment)
{
    ui->setupUi(this);

    setup();
}

BlockAlignment::~BlockAlignment()
{
    delete ui;
}

void BlockAlignment::setup()
{

    IconManager &iconManager = IconManager::instance();

    ui->buttonLeftAnchor->setIcon( iconManager.icon("align-left-anchor") );
    ui->buttonLeft->setIcon( iconManager.icon("align-left") );
    ui->buttonCenter->setIcon( iconManager.icon("align-center") );
    ui->buttonRight->setIcon( iconManager.icon("align-right") );
    ui->buttonRightAnchor->setIcon( iconManager.icon("align-right-anchor") );

    ui->buttonTopAnchor->setIcon( iconManager.icon("align-top-anchor") );
    ui->buttonTop->setIcon( iconManager.icon("align-top") );
    ui->buttonMiddle->setIcon( iconManager.icon("align-middle") );
    ui->buttonBottom->setIcon( iconManager.icon("align-bottom") );
    ui->buttonBottomAnchor->setIcon( iconManager.icon("align-bottom-anchor") );

}
