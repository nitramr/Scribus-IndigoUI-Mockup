#ifndef DOCK_CENTRALWIDGET_H
#define DOCK_CENTRALWIDGET_H

#include <DockWidget.h>

class DockCentralWidget : public ads::CDockWidget
{
    Q_OBJECT

public:
    explicit DockCentralWidget(QWidget *parent = nullptr);


};

#endif // DOCK_CENTRALWIDGET_H
