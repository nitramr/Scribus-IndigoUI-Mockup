#include "combobox_blendmode.h"
#include "enums.h"

ComboBoxBlendMode::ComboBoxBlendMode(QWidget *parent) : QComboBox(parent)
{
    this->addItem("Normal", ColorBlendMode::Normal);
    this->addItem("Darken", ColorBlendMode::Darken);
    this->addItem("Lighten", ColorBlendMode::Lighten);
    this->addItem("Multiply", ColorBlendMode::Multiply);
    this->addItem("Screen", ColorBlendMode::Screen);
    this->addItem("Overlay", ColorBlendMode::Overlay);
    this->addItem("Hard Light", ColorBlendMode::HardLight);
    this->addItem("Soft Light", ColorBlendMode::SoftLight);
    this->addItem("Difference", ColorBlendMode::Difference);
    this->addItem("Exclusion", ColorBlendMode::Exclusion);
    this->addItem("Color Dodge", ColorBlendMode::ColorDodge);
    this->addItem("Color Burn", ColorBlendMode::ColorBurn);
    this->addItem("Hue", ColorBlendMode::Hue);
    this->addItem("Saturation", ColorBlendMode::Saturation);
    this->addItem("Color", ColorBlendMode::Color);
    this->addItem("Luminosity", ColorBlendMode::Luminosity);

}
