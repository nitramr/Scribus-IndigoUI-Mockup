#ifndef ENUMS_H
#define ENUMS_H

/************************
 *
 * Color
 *
 * **********************/

/** Scribus color models */
enum ColorModel{
    RGB = 0,
    CMYK = 1,
    Lab = 2,
    HSV = 3
};

enum ItemFillMode {
    Solid = 0,
    Gradient = 1,
    Pattern = 2,
    Image = 3
};

enum GradientType {
    Linear = 0,
    Radial = 1,
    Conical = 2,
    Diamond = 3,
    FourColors = 4,
    Mesh = 5,
    PatchMesh = 6
};

enum ColorBlendMode {

    Normal = 0,
    Darken = 1,
    Lighten = 2,
    Multiply = 3,
    Screen = 4,
    Overlay = 5,
    HardLight = 6,
    SoftLight = 7,
    Difference = 8,
    Exclusion = 9,
    ColorDodge = 10,
    ColorBurn = 11,
    Hue = 12,
    Saturation = 13,
    Color = 14,
    Luminosity = 15
};

enum ColorPickerConfig {
    Default = 0,
    Fill = 1,
    FillMask = 2,
    Stroke = 3,
    StrokeMask = 4,
    Shadow = 5,
    Text = 6
};


/************************
 *
 * Page
 *
 * **********************/

enum PageLayout {
    Single = 0,
    Double = 1,
    ThreeFacing = 2,
    FourFacing = 3
};

enum FirstPage {
    Left = 0,
    MiddleLeft = 1,
    Middle = 2,
    MiddleRight = 3,
    Right

};

enum PageInsert {
    After = 0,
    Before = 1,
    AtEnd = 2,
    Swap = 3
};

#endif // ENUMS_H
