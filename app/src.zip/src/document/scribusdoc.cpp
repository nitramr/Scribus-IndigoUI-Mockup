#include "scribusdoc.h"

ScribusDoc::ScribusDoc():
    m_guardedObject(this)
{

}

const ScGuardedPtr<ScribusDoc>& ScribusDoc::guardedPtr() const
{
    return m_guardedObject;
}
